const voboclogin = document.querySelector('.voboclogin');
const linkdangnhap = document.querySelector('.linkdangnhap');
const linkdangky = document.querySelector('.linkdangky');
const iconclose = document.querySelector('.icon-close');
const btnCuaso = document.querySelector('.btnLogin-popup');
// var index = 1;
// changeImage = function(){
//     var imgs = ["/hinhanh/banner1.jpg","/hinhanh/banner2.jpg", "/hinhanh/banner3.jpg", "/hinhanh/banner4.jpg"];
//     document.getElementById('img').src = imgs[index];
//     index++;
//     if(index == 4){
//         index = 0;
//     }
// }
//     setInterval(changeImage,5000);
var countDownDate = new Date("Aug 31, 2023 00:00:00").getTime();
  
  var countdownClock = document.getElementById("countdown");
  var countdownInterval = setInterval(function() {
    var now = new Date().getTime();
    var remainingTime = countDownDate - now;
  
    var days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
    var hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);
  
    countdownClock.innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
  
    if (remainingTime < 0) {
      clearInterval(countdownInterval);
      countdownClock.innerHTML = "Đã hết thời gian";
    }
  }, 1000);
    
//-------------------------------------------------
linkdangky.addEventListener('click', () => {
    voboclogin.classList.add('active');
});

linkdangnhap.addEventListener('click', () => {
    voboclogin.classList.remove('active');
});

btnCuaso.addEventListener('click', () => {
    voboclogin.classList.add('active-popup');
});

iconclose.addEventListener('click', () => {
    voboclogin.classList.remove('active-popup');
});



//------------------------------------1

// Lắng nghe sự kiện click trên các liên kết menu
document.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', (event) => {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

    const targetId = link.getAttribute('href'); // Lấy giá trị của thuộc tính href
    const targetElement = document.querySelector(targetId); // Tìm phần tử cần cuộn đến

    if (targetElement) {
      // Sử dụng phương thức scrollIntoView để cuộn đến phần tử cần đến
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  });
});
// đổi màu
document.getElementById('trangden').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});
//vị trí tọa độ
window.addEventListener("load",function(){
  getLocation();
})
function getLocation() {
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(showPosition);
} else {
  alert("Geolocation không được hỗ trợ bởi trình duyệt này");
}
}

function showPosition(position) {
alert("Bạn đã cho phép trình duyệt này nhận vị trí của bạn");
let viTriCuaUser = "Vĩ độ: " + position.coords.latitude + ", Kinh độ: " + position.coords.longitude;
console.log(viTriCuaUser);
}
// phong to hình ảnh
// const images = document.querySelectorAll('.');

// images.forEach((image) => {
//   image.addEventListener('mouseenter', () => {
//     image.style.transform = 'scale(1.1)';
//     });

//   image.addEventListener('mouseleave', () => {
//     image.style.transform = 'scale(1)';
//   });
// });
// slideshow
document.getElementById('next').onclick = function(){
  let lists = document.querySelectorAll('.item');
  document.getElementById('slide').appendChild(lists[0]);
}

document.getElementById('prev').onclick = function(){
  let lists = document.querySelectorAll('.item');
  let lastItem = lists[lists.length - 1];
  document.getElementById('slide').prepend(lastItem);

}

// let slideIndex = 0;
// showSlides();

// function showSlides() { 
//   let slides = document.querySelectorAll('.item');
//   for (let i = 0; i < slides.length; i++) {
//     slides[i].style.display = 'none';
//   }
//   slideIndex++;
//   if (slideIndex > slides.length) {
//     slideIndex = 1;
//   }
//   slides[slideIndex - 1].style.display = 'block';
//   setTimeout(showSlides, 1000); // Chuyển đổi sau mỗi 5 giây
// }
const button = document.getElementById("mybutton");

// Thêm sự kiện "click" cho nút
document.querySelectorAll('.nenxe button').forEach(link => {
  link.addEventListener('click', (event) => {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của liên kết

    const targetId = link.getAttribute('href'); // Lấy giá trị của thuộc tính href
    const targetElement = document.querySelector(targetId); // Tìm phần tử cần cuộn đến

    if (targetElement) {
      // Sử dụng phương thức scrollIntoView để cuộn đến phần tử cần đến
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// const andanh = document.querySelector('.footer');
// andanh.addEventListener('click', () => {
//   voboclogin.classList.add('active-popup');
// });
document.getElementById('seemore').onclick = function() {
  let andanhDiv = document.getElementById('andanh');
  let footerDiv = document.getElementById('footertam');
  let xoaDiv = document.getElementById('seemore');

  if (andanhDiv.style.display === 'block') {
    andanhDiv.style.display = 'none';
  } else {
    andanhDiv.style.display = 'block';
    xoaDiv.remove();
    footerDiv.remove();
  }
}


const phoneInput = document.getElementById('registerPhone');
const phoneError = document.getElementById('phoneError');

phoneInput.addEventListener('input', () => {
  const phoneNumber = phoneInput.value.trim();
  if (/^\d{11}$/.test(phoneNumber)) {
    phoneError.textContent = ''; // Xóa thông báo lỗi nếu hợp lệ
  } else {
    phoneError.textContent = 'Số điện thoại không hợp lệ'; // Hiển thị thông báo lỗi
  }
});
